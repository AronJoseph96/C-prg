#include<stdio.h>
int main()
{
	int a,b,max;
	printf("Enter 2 numbers to find the max: ");
	scanf("%d%d",&a,&b);
	max=(a>b)?a:b;
	printf("Maximum = %d",max);
	return 0;
}
